# fvm02
virtual machine of 2 stacks
